jQuery(document).ready(function ($) {

    "use strict";


    jQuery(window).on("load", function () {
        var image_height = jQuery(".blog-grid img").height();
        var image_width = jQuery(".blog-grid img").width();
        jQuery(".blog-grid figure a::before").css({
            "height": image_height,
            "width": image_width,
            "background": "#f2f2f2",
        });
    });


//when scroll up show responsive btn.	
    var lastScroll = 0;
    $(window).scroll(function () {
        var scroll = $(window).scrollTop();
        if (scroll > lastScroll || scroll < 100) {
            $(".sticky-btn").removeClass("mobile");
        } else if (scroll < lastScroll) {
            $(".sticky-btn").addClass("mobile");
        }
        lastScroll = scroll;
    });

// top search
    $('.search-key').on("click", function () {
        $('.search-wraper').addClass('active');
        return false;
    });

    $('.close-search').on("click", function () {
        $('.search-wraper').removeClass('active');
        return false;
    });

// Responsive nav dropdowns
    $('.btn-area').on('click', function () {
        $('.responsive-menu').addClass('slidein');
        return false;
    });
    $('.close-menu > i').on('click', function () {
        $('.responsive-menu').removeClass('slidein');
        return false;
    });
    $('.responsive-menu ul li.menu-item-has-children > a').on('click', function () {
        $(this).parent().siblings().children('ul').slideUp();
        $(this).parent().siblings().removeClass('active');
        $(this).parent().children('ul').slideToggle();
        $(this).parent().toggleClass('active');
        return false;
    });

// auto typer typed	
    if ($.isFunction($.fn.typed)) {
        $(".m-content span").typed({
            strings: ["Stop Data Theft", "Recover Your Damage", "Get Fresh Android"],
            loop: true,
            startDelay: 1e3,
            backDelay: 3e3,
            typeSpeed: 30
        });
    }

// $fn.scrollSpeed(step, speed, easing);
    //jQuery.scrollSpeed(150, 900);

//----- sticky header
    if ($.isFunction($.fn.stickit)) {
        $('header.style1').stickit({scope: StickScope.Document});
    }
    new WOW().init();

//parallax
    if ($.isFunction($.fn.scrolly)) {
        $('.parallax').scrolly({bgParallax: true});
    }


//counter for funfacts
    if ($.isFunction($.fn.counterUp)) {
        $('.counter').counterUp({
            delay: 10,
            time: 1000
        });
    }

//----- count down timer		
    if ($.isFunction($.fn.downCount)) {
        $('.countdown').downCount({
            date: '11/12/2018 12:00:00',
            offset: +10
        });
    }

//accordion
    if ($.isFunction($.fn.ziehharmonika)) {
        $('.ziehharmonika').ziehharmonika({
            collapsible: true,
            collapseIconsAlign: 'right',
            collapseIcons: {
                opened: '&ndash;',
                closed: '+'
            },
        });
    }

//===== owl carousel  =====//
    if ($.isFunction($.fn.owlCarousel)) {
        $('.testimonials').owlCarousel({
            items: 1,
            loop: true,
            margin: 0,
            autoplay: true,
            autoplayTimeout: 1500,
            smartSpeed: 1000,
            autoplayHoverPause: true,
            nav: false,
            dots: true,
            animateIn: 'fadeIn',
            animateOut: 'fadeOut',
            responsiveClass: true,
            responsive: {
                0: {
                    items: 1,
                },
                600: {
                    items: 1,

                },
                1000: {
                    items: 1,
                }
            }

        });

        //services caro

        $('.serv-caro').owlCarousel({
            items: 1,
            loop: true,
            margin: 30,
            autoplay: false,
            autoplayTimeout: 1500,
            smartSpeed: 1000,
            autoplayHoverPause: true,
            nav: true,
            dots: false,
            animateIn: 'fadeIn',
            animateOut: 'fadeOut',
            responsiveClass: true,
            responsive: {
                0: {
                    items: 1,
                },
                600: {
                    items: 1,

                },
                1000: {
                    items: 1,
                }
            }

        });

        $('.services-caro').owlCarousel({
            loop: true,
            margin: 30,
            autoplay: true,
            autoplayTimeout: 1500,
            smartSpeed: 1000,
            autoplayHoverPause: true,
            nav: true,
            dots: false,
            responsiveClass: true,
            responsive: {
                0: {
                    items: 1,
                    nav: false
                },
                600: {
                    items: 2,

                },
                1000: {
                    items: 4,
                }
            }

        });

        //about us carousel home2
        $('.about-caro').owlCarousel({
            loop: true,
            margin: 20,
            autoplay: false,
            autoplayTimeout: 1500,
            smartSpeed: 1000,
            autoplayHoverPause: true,
            nav: true,
            dots: false,
            responsiveClass: true,
            responsive: {
                0: {
                    items: 1,
                    nav: false
                },
                600: {
                    items: 3,

                },
                1000: {
                    items: 3,
                }
            }

        });

    }

//--- bootstrap tooltip	
    $(function () {
        $('[data-toggle="tooltip"]').tooltip();
    });

//scrollbar plugin
    if ($.isFunction($.fn.perfectScrollbar)) {
        $('.responsive-menu').perfectScrollbar();
    }
    
    $('form #submit').on('click',function(){
	    var button_id = $(this).attr('id');
	    var form = $(this).parent().parent().parent();
	    var action = $(form).attr('action');
	    var msg = $("form .error-alert");
	    var _name = $(form).find('input[name="name"]').val();
	    var _email = $(form).find('input[name="email"]').val();
	    var _phone = $(form).find('input[name="phone"]').val();
	    var _comments = $(form).find('textarea[name="comments"]').val();
	
	    $.post(action, {
	        name: _name,
	        email: _email,
	        phone: _phone,
	        comments: _comments,
	    },
	        function(data){
	            $(msg).html(data);
	            $(this).removeAttr('disabled');
	
	        }
	    );

    		return false;
	});
});//document ready end


// Animate loader off screen
$(window).on('load', function () {
    "use strict";
    $(".se-pre-con").fadeOut("slow");

});//window.load end here


//form validation just add "required" attribute in input fileds.
$(function () {
    var createAllErrors = function () {
        var form = $(this);
        var errorList = $('ul.errorMessages', form);

        var showAllErrorMessages = function () {
            errorList.empty();

            //Find all invalid fields within the form.
            form.find(':invalid').each(function (index, node) {

                //Find the field's corresponding label
                var label = $('label[for=' + node.id + ']');

                //Opera incorrectly does not fill the validationMessage property.
                var message = node.validationMessage || 'Invalid value.';
                errorList
                    .show()
                    .append('<li><span>' + label.html() + '</span> ' + message + '</li>');
            });
        };

        $('input[type=submit], button', form).on('click', showAllErrorMessages);
        $('input[type=text]', form).on('keypress', function (event) {
            //keyCode 13 is Enter
            if (event.keyCode == 13) {
                showAllErrorMessages();
            }
        });
    };

    $('form').each(createAllErrors);
});

$(window).on('load', function () {
    'use strict';
    $(function () {
        $('.chart').easyPieChart({
            scaleColor: "transparent",
            lineWidth: 10,
            lineCap: 'round',
            barColor: '#ffa200',
            trackColor: "#fff",
            size: 200,
            animate: 1000
        });
    });
});	

