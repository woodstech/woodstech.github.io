$(window).load(function()
{
	$("#logo img").vAlign();
});