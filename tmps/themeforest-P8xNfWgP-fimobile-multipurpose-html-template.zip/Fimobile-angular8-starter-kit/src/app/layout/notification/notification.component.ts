import { Component, OnInit, AfterViewInit } from '@angular/core';
import { routerTransition } from '../../router.animations';

@Component({
    selector: 'app-notification',
    templateUrl: './notification.component.html',
    styleUrls: ['./notification.component.scss'],
    animations: [routerTransition()]
})
export class NotificationComponent implements OnInit {
    constructor() {
    }
    ngOnInit() {
    }

}
