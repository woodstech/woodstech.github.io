 module.exports = function(grunt){
	"use strict";
	grunt.initConfig({
		  concat: {
		    dist: {
		      src: [
				  'css/font-awesome.min.css', 
				  'css/bootstrap.min.css', 
				  'css/animate.min.css', 
				  'css/owl.carousel.css',
				  'css/silk-accordion.css',
				  'css/perfect-scrollbar.css'
			      ],
		      dest: 'css/main.css',
		    },
			  
		    extras: {
		      src: [
				  'js/jquery.js', 
				  'js/popperjs-bootstrap.js',
				  'js/bootstrap.min.js', 
				  'js/waypoints.js', 
				  'js/owl.carousel.min.js',
				  'js/scrolltopcontrol.js', 
				  'js/jquery.stickit.js',
				  'js/jquery.scrolly.js', 
				  'js/isotope.min.js', 
				  'js/isotope-init.js', 
				  'js/jquery.downCount.js', 
				  'js/silk-accordion.js',
				  'js/wow.min.js',
				  'js/jquery.counterup.min.js',
				  'js/html5lightbox.js',
				  'js/pie-chart.js',
				  'js/typed.js',
				  'js/perfect-scrollbar.min.js',
				  'js/perfect-scrollbar.jquery.js'
			  ],
		      dest: 'js/main.min.js',
		    },
		  },

		  cssmin: {
		    target: {
			    files: {
			      'css/main.css': 
					[
					  'css/font-awesome.min.css', 
					  'css/bootstrap.min.css', 
					  'css/animate.min.css', 
					  'css/owl.carousel.css',
					  'css/silk-accordion.css',
					  'css/perfect-scrollbar.css'
					],
			    }
			  }
		  },

		uglify: {
		    my_target: {
		      files: {
		        'js/main.min.js': 
				 [
				  'js/jquery.js', 
				  'js/popperjs-bootstrap.js',
				  'js/bootstrap.min.js',
				  'js/waypoints.js',  
				  'js/owl.carousel.min.js',
				  'js/scrolltopcontrol.js', 
				  'js/jquery.stickit.js',
				  'js/jquery.scrolly.js', 
				  'js/isotope.min.js', 
				  'js/isotope-init.js', 
				  'js/jquery.downCount.js', 
				  'js/silk-accordion.js',
				  'js/wow.min.js',
				  'js/jquery.counterup.min.js',
				  'js/html5lightbox.js',
				  'js/pie-chart.js',
				  'js/typed.js',
				  'js/perfect-scrollbar.min.js',
				  'js/perfect-scrollbar.jquery.js'
				 ]
		      },
		    },
		  },
		
		watch: {
		  configFiles: {
		    files: 
			  [
				  'css/font-awesome.min.css', 
				  'css/bootstrap.min.css', 
				  'css/animate.min.css', 
				  'css/owl.carousel.css', 
				  'css/slick.css',
			  ],
		    options: {
		      reload: true
		    },
		  },
		},
	  
	});

	//load the plugins
	grunt.loadNpmTasks('grunt-contrib-concat');
	grunt.loadNpmTasks('grunt-contrib-cssmin');
	grunt.loadNpmTasks('grunt-contrib-watch');
	grunt.loadNpmTasks('grunt-contrib-uglify');
};